
var nombre = prompt('cual es su nombre?');

if(nombre =='paola') {
	alert('Bienvenido: '+nombre+' el aprendiz');
} else {
	alert('Bienvenido: '+nombre+' el instructor');
}